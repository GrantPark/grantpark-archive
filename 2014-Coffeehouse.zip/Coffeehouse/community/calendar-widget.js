
$(document).ready(function () {
	$('#localCalendar').load('index.html', function(){
	});
});
